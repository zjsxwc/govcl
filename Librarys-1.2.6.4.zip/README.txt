﻿所有Windows下的二进制都采用upx 3.9.4w进行压缩。

压缩包内包含的“libvcl”库二进制（libvcl.dll、libvclx64.dll）仅供预览和测试使用。正式使用请自行编译“libvcl”源代码，具体编译方法参考UILIbSrcources中的说明。

1、libvcl.dll、libvclx64.dll、liblcl.dll于Windows 10下编译。
2、liblcl.so于Linux Mint 17.1下编译。
3、liblcl.dylib于macOS High Sierra 10.13.4下编译。




All binary under Windows are compressed by upx 3.9.4w.  

Note: The "libvcl" library binary (libvcl. dll, libvclx64. dll) contained in the compression package is only for preview and test purposes. Please compile the "libvcl" source code for official use. please refer to the instructions in UILIbSrcources.

1, libvcl.dll, libvclx64.dll, liblcl.dll compiled under Windows 10.
2, liblcl.so compiled under Linux Mint 17.1.
3, liblcl.dylib compiled under macOS High Sierra 10.13.4.





